(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const screen = $('#screen');
  const selectedStrip = $('#selectedStrip');
  const networkDot = $('#networkDot');
  const networkText = $('#networkText');
  const refreshButton = $('#refreshButton');

  const state = {
    activeTab: localStorage.getItem('a99_tab') || 'home',
    matches: [],
    selectedId: localStorage.getItem('a99_selected_match') || '',
    selectedDetails: null,
    scorecard: null,
    commentary: [],
    loadingMatches: true,
    loadingDetails: false,
    muted: localStorage.getItem('a99_muted') === '1',
    reminders: new Set(JSON.parse(localStorage.getItem('a99_reminders') || '[]')),
    requestSequence: 0,
    pending: new Map(),
    lastBallKey: localStorage.getItem('a99_last_ball_key') || '',
    previousScoreFingerprint: '',
    globalTimer: null,
    detailTimer: null,
    scorecardTick: 0,
    lastApiError: '',
    lastUpdatedAt: 0,
    refreshingMatches: false,
    pageAnimation: '',
    apiInfo: null,
    detailCycle: 0
  };

  window.A99Native = {
    onApiResponse(requestId, payload) {
      const pending = state.pending.get(requestId);
      if (!pending) return;
      state.pending.delete(requestId);
      try {
        const json = JSON.parse(payload);
        if (String(json.status || '').toLowerCase() === 'failure') {
          pending.reject(new Error(json.reason || 'Live data unavailable'));
        } else {
          pending.resolve(json);
        }
      } catch (error) {
        pending.reject(error);
      }
    }
  };

  const nativeAvailable = () => window.A99Android && typeof window.A99Android.requestApi === 'function';

  function api(endpoint, params = {}, timeout = 12500) {
    return new Promise((resolve, reject) => {
      if (!nativeAvailable()) {
        reject(new Error('Android API bridge unavailable'));
        return;
      }
      const id = `a99_${Date.now()}_${++state.requestSequence}`;
      state.pending.set(id, { resolve, reject });
      window.A99Android.requestApi(endpoint, JSON.stringify(params), id);
      setTimeout(() => {
        const item = state.pending.get(id);
        if (item) {
          state.pending.delete(id);
          reject(new Error('Live data request timed out'));
        }
      }, timeout);
    });
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function safeArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function initials(name) {
    return String(name || 'TBC').split(/\s+/).filter(Boolean).slice(0, 2).map(x => x[0]).join('').toUpperCase();
  }

  function teamInfo(match, index) {
    const name = safeArray(match.teams)[index] || `Team ${index + 1}`;
    const details = safeArray(match.teamInfo).find(t => String(t.name || '').toLowerCase() === String(name).toLowerCase())
      || safeArray(match.teamInfo)[index]
      || {};
    return { name, image: details.img || details.image || '' };
  }

  function teamHtml(team, right = false) {
    const media = team.image
      ? `<img class="team-logo" src="${escapeHtml(team.image)}" alt="" onerror="this.outerHTML='<span class=&quot;team-fallback&quot;>${escapeHtml(initials(team.name))}</span>'">`
      : `<span class="team-fallback">${escapeHtml(initials(team.name))}</span>`;
    return `<div class="team ${right ? 'right' : ''}">${right ? `<b>${escapeHtml(team.name)}</b>${media}` : `${media}<b>${escapeHtml(team.name)}</b>`}</div>`;
  }

  function parseDate(match) {
    const raw = match.dateTimeGMT || match.date || '';
    if (!raw) return null;
    let date;
    if (/^\d{4}-\d{2}-\d{2}T/.test(raw)) date = new Date(raw.endsWith('Z') ? raw : `${raw}Z`);
    else if (/^\d{4}-\d{2}-\d{2}/.test(raw)) date = new Date(`${raw.replace(' ', 'T')}Z`);
    else date = new Date(raw);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function formatIst(match) {
    const date = parseDate(match);
    if (!date) return 'Time unavailable';
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit', month: 'short',
      hour: 'numeric', minute: '2-digit', hour12: true
    }).format(date) + ' IST';
  }

  function isBreakStatus(status) {
    return /(rain|stumps|lunch|tea|break|drinks|bad light|delay|interruption)/i.test(status || '');
  }

  function readableStatus(match) {
    const raw = String(match.status || '').trim();
    if (/rain/i.test(raw)) return 'Play stopped — Rain';
    if (/stumps/i.test(raw)) return 'Stumps';
    if (/innings break/i.test(raw)) return 'Innings Break';
    if (/lunch/i.test(raw)) return 'Lunch Break';
    if (/tea/i.test(raw)) return 'Tea Break';
    if (/drinks/i.test(raw)) return 'Drinks Break';
    if (/bad light/i.test(raw)) return 'Play stopped — Bad Light';
    if (/delay|delayed/i.test(raw)) return raw || 'Match Delayed';
    if (/abandon/i.test(raw)) return 'Match Abandoned';
    if (raw) return raw;
    if (match.matchEnded) return 'Match completed';
    if (match.matchStarted) return 'Match in progress';
    return `Starts ${formatIst(match)}`;
  }

  function matchPhase(match) {
    const status = readableStatus(match);
    if (match.matchEnded || /(won by|drawn|tied|completed|abandoned)/i.test(status)) return 'done';
    if (isBreakStatus(status)) return 'break';
    if (match.matchStarted || /(live|in progress)/i.test(status)) return 'live';
    return 'upcoming';
  }

  function normalizeMatch(match) {
    if (!match || !match.id) return null;
    return {
      ...match,
      id: String(match.id),
      name: match.name || safeArray(match.teams).join(' vs ') || 'Cricket match',
      teams: safeArray(match.teams),
      teamInfo: safeArray(match.teamInfo),
      score: safeArray(match.score),
      matchStarted: Boolean(match.matchStarted),
      matchEnded: Boolean(match.matchEnded)
    };
  }

  function mergeMatches(...lists) {
    const map = new Map();
    lists.flat().map(normalizeMatch).filter(Boolean).forEach(match => {
      const previous = map.get(match.id) || {};
      map.set(match.id, { ...previous, ...match, score: match.score.length ? match.score : (previous.score || []) });
    });
    return Array.from(map.values()).sort((a, b) => {
      const phaseOrder = { live: 0, break: 1, upcoming: 2, done: 3 };
      const phaseDiff = phaseOrder[matchPhase(a)] - phaseOrder[matchPhase(b)];
      if (phaseDiff) return phaseDiff;
      return (parseDate(a)?.getTime() || Infinity) - (parseDate(b)?.getTime() || Infinity);
    });
  }

  function getSelected() {
    return state.matches.find(match => match.id === state.selectedId) || null;
  }

  function scoreText(score) {
    if (!score) return '';
    const runs = Number.isFinite(Number(score.r)) ? Number(score.r) : '-';
    const wickets = Number.isFinite(Number(score.w)) ? Number(score.w) : '-';
    const overs = score.o !== undefined && score.o !== null ? score.o : '-';
    return `${runs}/${wickets} (${overs})`;
  }

  function scoreChips(match) {
    const scores = safeArray(match?.score);
    if (!scores.length) return `<span class="score-chip">Score will update automatically</span>`;
    return scores.map(item => `<span class="score-chip">${escapeHtml(item.inning || '')} ${escapeHtml(scoreText(item))}</span>`).join('');
  }

  function statusPill(match) {
    const phase = matchPhase(match);
    const label = phase === 'live' ? 'Live' : phase === 'break' ? 'Break' : phase === 'done' ? 'Result' : 'Upcoming';
    return `<span class="status-pill ${phase === 'break' ? 'break' : phase === 'done' ? 'done' : ''}">${label}</span>`;
  }

  function matchCard(match) {
    const a = teamInfo(match, 0);
    const b = teamInfo(match, 1);
    return `<button class="match-card ${match.id === state.selectedId ? 'selected' : ''}" data-match-id="${escapeHtml(match.id)}">
      <div class="match-top"><span class="series">${escapeHtml(match.name)}</span>${statusPill(match)}</div>
      <div class="teams-row">${teamHtml(a)}<span class="vs">VS</span>${teamHtml(b, true)}</div>
      <div class="score-line">${scoreChips(match)}</div>
      <div class="match-meta"><span>${escapeHtml(match.matchType || 'Cricket')}</span><span>${escapeHtml(match.venue || formatIst(match))}</span></div>
    </button>`;
  }

  function emptyState(title, text, icon = '◌') {
    return `<div class="empty-state"><div class="empty-icon">${icon}</div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(text)}</p></div>`;
  }

  function friendlyApiError(message) {
    const raw = String(message || 'Live match feed unavailable').trim();
    if (/limit|quota|hits? (?:finished|exceed|used)|daily/i.test(raw)) {
      return 'API daily hit limit finished. It will work after the provider resets the quota or after adding a higher-limit key.';
    }
    if (/api.?key|unauthor|invalid key|configuration missing/i.test(raw)) {
      return 'Cricket API key is invalid or missing.';
    }
    if (/timed out|timeout/i.test(raw)) return 'Cricket server response timed out. Tap refresh after a moment.';
    if (/unable to resolve|name resolution|host|network/i.test(raw)) return 'Cricket server could not be reached. Check internet and try refresh.';
    return raw;
  }

  async function refreshMatches() {
    if (state.refreshingMatches) return;
    state.refreshingMatches = true;
    refreshButton?.classList.add('loading');
    try {
      // One list request instead of four. The free key allows only 100 hits/day.
      const response = await api('matches', { offset: 0 });
      const fetched = safeArray(response.data);
      state.apiInfo = response.info || null;
      if (fetched.length) {
        state.matches = mergeMatches(fetched);
        state.lastUpdatedAt = Date.now();
        localStorage.setItem('a99_matches_cache', JSON.stringify(state.matches.slice(0, 80)));
        if (!state.selectedId || !state.matches.some(m => m.id === state.selectedId)) {
          state.selectedId = (state.matches.find(m => ['live', 'break'].includes(matchPhase(m))) || state.matches.find(m => matchPhase(m) === 'upcoming') || state.matches[0])?.id || '';
          if (state.selectedId) localStorage.setItem('a99_selected_match', state.selectedId);
        }
        state.lastApiError = '';
      } else {
        state.lastApiError = 'The API returned an empty match list.';
      }
    } catch (error) {
      state.lastApiError = friendlyApiError(error.message);
    } finally {
      state.loadingMatches = false;
      state.refreshingMatches = false;
      refreshButton?.classList.remove('loading');
      render();
      const selected = getSelected();
      if (selected && ['live', 'break'].includes(matchPhase(selected)) && ['live', 'commentary', 'scorecard'].includes(state.activeTab)) {
        updateSelectedDetails(false);
      }
    }
  }

  function selectedBaseMatch() {
    const selected = getSelected();
    if (!selected) return null;
    const detail = state.selectedDetails?.data || state.selectedDetails || {};
    return normalizeMatch({ ...selected, ...detail, score: safeArray(detail.score).length ? detail.score : selected.score }) || selected;
  }

  async function updateSelectedDetails(forceScorecard = false) {
    const selected = getSelected();
    if (!selected || state.loadingDetails) return;
    if (!['live', 'break'].includes(matchPhase(selected)) && !forceScorecard) return;

    state.loadingDetails = true;
    const idAtStart = selected.id;
    state.detailCycle += 1;
    try {
      let endpoint = 'match_info';
      if (state.activeTab === 'commentary') endpoint = 'match_bbb';
      else if (state.activeTab === 'scorecard' || forceScorecard) endpoint = 'match_scorecard';
      else if (state.activeTab === 'live' && !state.muted && state.detailCycle % 2 === 0) endpoint = 'match_bbb';

      const result = await api(endpoint, { id: selected.id });
      if (getSelected()?.id !== idAtStart) return;
      state.apiInfo = result.info || state.apiInfo;

      if (endpoint === 'match_info') {
        state.selectedDetails = result;
        const detail = result.data || {};
        const index = state.matches.findIndex(m => m.id === idAtStart);
        if (index >= 0) state.matches[index] = { ...state.matches[index], ...detail };
        announceScoreChange(selectedBaseMatch());
      } else if (endpoint === 'match_bbb') {
        const commentary = extractCommentary(result.data ?? result);
        if (commentary.length) {
          state.commentary = commentary;
          localStorage.setItem(`a99_commentary_${idAtStart}`, JSON.stringify(commentary.slice(0, 80)));
          announceLatestBall(commentary[0], selectedBaseMatch());
        }
      } else if (endpoint === 'match_scorecard') {
        state.scorecard = result;
        localStorage.setItem(`a99_scorecard_${idAtStart}`, JSON.stringify(state.scorecard));
      }
      state.lastApiError = '';
    } catch (error) {
      state.lastApiError = friendlyApiError(error.message);
    } finally {
      state.loadingDetails = false;
      render();
    }
  }

  function extractCommentary(root) {
    const rows = [];
    const seen = new Set();
    const visit = (value, path = '') => {
      if (!value) return;
      if (Array.isArray(value)) {
        value.forEach((item, index) => visit(item, `${path}.${index}`));
        return;
      }
      if (typeof value !== 'object') return;

      const lower = Object.fromEntries(Object.entries(value).map(([k, v]) => [k.toLowerCase(), v]));
      const commentary = lower.commentary || lower.comment || lower.text || lower.description || lower.event || lower.outcome || lower.result;
      const over = lower.over ?? lower.overnumber ?? lower.over_number;
      const ball = lower.ball ?? lower.ballnumber ?? lower.ball_number;
      const runs = lower.runs ?? lower.run;
      const wicket = lower.wicket ?? lower.iswicket ?? lower.is_wicket ?? lower.dismissal;
      const extras = lower.extras ?? lower.extra;

      let text = commentary ? String(commentary) : '';
      if (!text && (runs !== undefined || wicket !== undefined || extras !== undefined)) {
        if (wicket === true || wicket === 1 || /out|wicket/i.test(String(wicket))) text = 'Wicket';
        else if (extras && typeof extras === 'object') {
          const noBall = Number(extras.noballs ?? extras.noball ?? 0);
          const wide = Number(extras.wides ?? extras.wide ?? 0);
          if (noBall) text = 'No ball';
          else if (wide) text = 'Wide';
        }
        if (!text && runs !== undefined) text = Number(runs) === 0 ? 'Dot ball' : `${runs} run${Number(runs) === 1 ? '' : 's'}`;
      }

      const pathSuggestsBall = /(ball|bbb|comment|delivery|over)/i.test(path);
      const hasBallSignal = pathSuggestsBall || over !== undefined || ball !== undefined
        || runs !== undefined || wicket !== undefined || extras !== undefined;

      if (text && hasBallSignal) {
        const label = over !== undefined ? `${over}${ball !== undefined ? `.${ball}` : ''}` : (lower.ballid || lower.id || 'Ball');
        const key = `${label}|${text}`.toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          rows.push({ label: String(label), text: String(text), sort: Number(String(label).replace(/[^0-9.]/g, '')) || rows.length });
        }
      }
      Object.entries(value).forEach(([key, child]) => {
        if (typeof child === 'object' && child !== null) visit(child, `${path}.${key}`);
      });
    };
    visit(root);
    return rows.sort((a, b) => b.sort - a.sort).slice(0, 100);
  }

  function eventVoice(text) {
    const value = String(text || '').toLowerCase();
    if (/no[ -]?ball/.test(value)) return 'No ball';
    if (/wide/.test(value)) return 'Wide';
    if (/wicket|\bout\b|dismiss/.test(value)) return 'Out';
    if (/\bsix\b|\b6 runs?\b|\b6\b/.test(value)) return 'Six';
    if (/\bfour\b|\b4 runs?\b|\b4\b/.test(value)) return 'Four';
    if (/\bthree\b|\b3 runs?\b|\b3\b/.test(value)) return 'Triple';
    if (/\btwo\b|\b2 runs?\b|\b2\b/.test(value)) return 'Double';
    if (/\bone\b|\b1 run\b|single/.test(value)) return 'Single';
    if (/dot|no run|0 run/.test(value)) return 'Dot ball';
    return '';
  }

  function announceLatestBall(ball, match) {
    if (!ball || !match || state.muted || matchPhase(match) === 'done') return;
    const event = eventVoice(ball.text);
    if (!event) return;
    const key = `${match.id}|${ball.label}|${ball.text}`;
    if (key === state.lastBallKey) return;
    state.lastBallKey = key;
    localStorage.setItem('a99_last_ball_key', key);
    try { window.A99Android.speak(`Ball start. ${event}`); } catch (_) {}
  }

  function aggregateFingerprint(match) {
    const last = safeArray(match?.score).slice(-1)[0];
    if (!last) return '';
    return `${match.id}|${last.r ?? ''}|${last.w ?? ''}|${last.o ?? ''}`;
  }

  function announceScoreChange(match) {
    if (!match || state.muted || !['live', 'break'].includes(matchPhase(match))) return;
    const fingerprint = aggregateFingerprint(match);
    if (!fingerprint) return;
    if (!state.previousScoreFingerprint) {
      state.previousScoreFingerprint = fingerprint;
      return;
    }
    const previous = state.previousScoreFingerprint.split('|');
    const current = fingerprint.split('|');
    if (previous[0] !== current[0]) {
      state.previousScoreFingerprint = fingerprint;
      return;
    }
    const runDelta = Number(current[1]) - Number(previous[1]);
    const wicketDelta = Number(current[2]) - Number(previous[2]);
    const overChanged = current[3] !== previous[3];
    let event = '';
    if (wicketDelta > 0) event = 'Out';
    else if (runDelta === 6) event = 'Six';
    else if (runDelta === 4) event = 'Four';
    else if (runDelta === 3) event = 'Triple';
    else if (runDelta === 2) event = 'Double';
    else if (runDelta === 1) event = 'Single';
    else if (runDelta === 0 && overChanged) event = 'Dot ball';
    state.previousScoreFingerprint = fingerprint;
    if (event) {
      try { window.A99Android.speak(`Ball start. ${event}`); } catch (_) {}
    }
  }

  function projectionFor(match) {
    const a = teamInfo(match, 0).name;
    const b = teamInfo(match, 1).name;
    if (matchPhase(match) === 'done') {
      const status = readableStatus(match);
      if (new RegExp(a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(status) && /won/i.test(status)) return { a, b, pa: 100, pb: 0 };
      if (new RegExp(b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(status) && /won/i.test(status)) return { a, b, pa: 0, pb: 100 };
      return { a, b, pa: 50, pb: 50 };
    }

    const scores = safeArray(match.score);
    let pa = 50;
    if (scores.length >= 2) {
      const first = scores[0];
      const latest = scores[scores.length - 1];
      const target = Number(first.r || 0) + 1;
      const current = Number(latest.r || 0);
      const wickets = Number(latest.w || 0);
      const type = String(match.matchType || '').toLowerCase();
      const maxOvers = type.includes('odi') ? 50 : type.includes('t20') ? 20 : 90;
      const usedOvers = Number(latest.o || 0);
      const ballsLeft = Math.max(1, Math.round((maxOvers - usedOvers) * 6));
      const runsNeeded = Math.max(0, target - current);
      const requiredPerBall = runsNeeded / ballsLeft;
      const wicketFactor = Math.max(.15, (10 - wickets) / 10);
      const chaseChance = 1 / (1 + Math.exp((requiredPerBall - .85) * 4.2));
      const adjusted = Math.max(.03, Math.min(.97, chaseChance * (.62 + .38 * wicketFactor)));
      const chasingIsA = String(latest.inning || '').toLowerCase().includes(a.toLowerCase());
      pa = Math.round((chasingIsA ? adjusted : 1 - adjusted) * 100);
    } else if (scores.length === 1) {
      const latest = scores[0];
      const runs = Number(latest.r || 0);
      const wickets = Number(latest.w || 0);
      const overs = Number(latest.o || 0);
      const momentum = Math.max(-14, Math.min(14, (runs / Math.max(1, overs) - 7) * 2 - wickets * .65));
      const battingIsA = String(latest.inning || '').toLowerCase().includes(a.toLowerCase());
      pa = Math.round(50 + (battingIsA ? momentum : -momentum));
    }
    pa = Math.max(5, Math.min(95, pa));
    return { a, b, pa, pb: 100 - pa };
  }

  function projectionHtml(match) {
    const p = projectionFor(match);
    return `<section class="projection">
      <div class="projection-head"><b>Win projection</b><small>Live data model</small></div>
      <div class="projection-labels"><span>${escapeHtml(p.a)} ${p.pa}%</span><span>${escapeHtml(p.b)} ${p.pb}%</span></div>
      <div class="projection-track"><span style="width:${p.pa}%"></span><span style="width:${p.pb}%"></span></div>
      <p class="safe-note">Informational match projection only.</p>
    </section>`;
  }

  function renderSelectedStrip() {
    const match = selectedBaseMatch() || getSelected();
    if (!match) {
      selectedStrip.classList.add('hidden');
      selectedStrip.innerHTML = '';
      return;
    }
    const a = teamInfo(match, 0).name;
    const b = teamInfo(match, 1).name;
    selectedStrip.classList.remove('hidden');
    selectedStrip.innerHTML = `<div class="teams"><b>${escapeHtml(a)} vs ${escapeHtml(b)}</b><small>${escapeHtml(readableStatus(match))}</small></div><span class="switch-label">SYNCED MATCH</span>`;
  }

  function renderHome() {
    const live = state.matches.filter(m => ['live', 'break'].includes(matchPhase(m)));
    const upcoming = state.matches.filter(m => matchPhase(m) === 'upcoming');
    const apiAlert = state.lastApiError ? `<section class="api-alert"><b>API feed problem</b><span>${escapeHtml(state.lastApiError)}</span><small>Tap the refresh icon after checking the API dashboard.</small></section>` : '';
    return `<section class="hero">
      <span class="eyebrow">Real API feed</span>
      <h1>One match. Every screen in sync.</h1>
      <p>Select any fixture once. Live, commentary and scorecard automatically follow the same match.</p>
      <div class="hero-stats">
        <div class="hero-stat"><b>${live.length}</b><span>Live</span></div>
        <div class="hero-stat"><b>${upcoming.length}</b><span>Upcoming</span></div>
        <div class="hero-stat"><b>SMART</b><span>Quota-safe refresh</span></div>
      </div>
    </section>${apiAlert}
    <div class="section-head mt-16"><div><h2>Live now</h2><p>Automatic score and match-status updates</p></div></div>
    <div class="card-list two-col">${live.length ? live.slice(0, 6).map(matchCard).join('') : emptyState('No live match right now', 'Upcoming fixtures are available below.', '●')}</div>
    <div class="section-head mt-16"><div><h2>Coming up</h2><p>Times shown in Indian Standard Time</p></div></div>
    <div class="card-list two-col">${upcoming.length ? upcoming.slice(0, 8).map(matchCard).join('') : emptyState('No upcoming fixtures returned', state.lastApiError || 'The real API will refresh automatically.', '▦')}</div>`;
  }

  function renderFixtures() {
    const visible = state.matches.filter(m => matchPhase(m) !== 'done');
    return `<div class="section-head"><div><span class="eyebrow">Fixtures</span><h1>Running & upcoming</h1><p>Real API match list • tap to sync all screens</p></div></div>
      <div class="card-list">${visible.length ? visible.map(matchCard).join('') : emptyState('Fixtures unavailable', state.lastApiError || 'The app will retry automatically.', '▦')}</div>`;
  }

  function renderLive() {
    const match = selectedBaseMatch() || getSelected();
    if (!match) return `<div class="section-head"><div><span class="eyebrow">Live</span><h1>Match Center</h1></div></div>${emptyState('Select a match first', 'Choose a running or upcoming match from Home or Fixtures.', '●')}`;
    const teamA = teamInfo(match, 0);
    const teamB = teamInfo(match, 1);
    const phase = matchPhase(match);
    const teamVisual = team => team.image
      ? `<img class="tv-team-logo" src="${escapeHtml(team.image)}" alt="" onerror="this.outerHTML='<span class=&quot;tv-team-fallback&quot;>${escapeHtml(initials(team.name))}</span>'">`
      : `<span class="tv-team-fallback">${escapeHtml(initials(team.name))}</span>`;
    return `<div class="section-head"><div><span class="eyebrow">Live</span><h1>Match Center</h1><p>Automatic fast live updates and ball voice</p></div></div>
      <section class="tv-box">
        <div class="tv-head"><span class="live-dot">${phase === 'upcoming' ? 'MATCH HUB' : phase === 'done' ? 'RESULT' : phase === 'break' ? 'PLAY BREAK' : 'LIVE FEED'}</span><div class="tv-actions">${phase === 'upcoming' ? `<button id="reminderToggle" class="reminder-button ${state.reminders.has(match.id) ? 'active' : ''}">${state.reminders.has(match.id) ? '✓ Reminder' : '🔔 Remind 15m'}</button>` : ''}<button id="soundToggle" class="sound-button">${state.muted ? '🔇 Muted' : '🔊 Sound'}</button></div></div>
        <div class="tv-body">
          <div class="tv-series">${escapeHtml(match.name)}</div>
          <div class="tv-team-grid">
            <div class="tv-team">${teamVisual(teamA)}<b>${escapeHtml(teamA.name)}</b></div>
            <span class="tv-versus">VS</span>
            <div class="tv-team">${teamVisual(teamB)}<b>${escapeHtml(teamB.name)}</b></div>
          </div>
          <div class="tv-score">${scoreChips(match)}</div>
          <div class="play-status">${escapeHtml(readableStatus(match))}</div>
          <div class="tv-meta"><span>${escapeHtml(match.matchType || 'Cricket')}</span><span>${escapeHtml(match.venue || formatIst(match))}</span></div>
        </div>
      </section>
      ${projectionHtml(match)}`;
  }

  function renderCommentary() {
    const match = selectedBaseMatch() || getSelected();
    if (!match) return `<div class="section-head"><div><span class="eyebrow">Commentary</span><h1>Ball-by-ball</h1></div></div>${emptyState('No match selected', 'Select a match from Fixtures.', '≋')}`;
    const cached = state.commentary.length ? state.commentary : (() => {
      try { return JSON.parse(localStorage.getItem(`a99_commentary_${match.id}`) || '[]'); } catch (_) { return []; }
    })();
    return `<div class="section-head"><div><span class="eyebrow">Commentary</span><h1>${escapeHtml(teamInfo(match,0).name)} vs ${escapeHtml(teamInfo(match,1).name)}</h1><p>${escapeHtml(readableStatus(match))}</p></div></div>
      <div class="commentary-list">${cached.length ? cached.map(commentaryRow).join('') : emptyState('Commentary not published yet', 'This screen updates automatically for the selected match.', '≋')}</div>`;
  }

  function scorecardData() {
    const raw = state.scorecard?.data ?? state.scorecard ?? {};
    if (Array.isArray(raw)) return raw;
    if (Array.isArray(raw.scorecard)) return raw.scorecard;
    if (Array.isArray(raw.innings)) return raw.innings;
    return [];
  }

  function playerRows(innings) {
    const batting = safeArray(innings.batting || innings.batsmen || innings.batsman);
    if (!batting.length) return '';
    return batting.map(player => `<tr>
      <td>${escapeHtml(player.batsman?.name || player.name || player.batsman || player.player || '-')}</td>
      <td>${escapeHtml(player.dismissal || player.outDesc || player['dismissal-text'] || '-')}</td>
      <td>${escapeHtml(player.r ?? player.runs ?? '-')}</td>
      <td>${escapeHtml(player.b ?? player.balls ?? '-')}</td>
      <td>${escapeHtml(player['4s'] ?? player.fours ?? '-')}</td>
      <td>${escapeHtml(player['6s'] ?? player.sixes ?? '-')}</td>
    </tr>`).join('');
  }

  function inningsHtml(innings, index) {
    const title = innings.inning || innings.name || innings.team || `Innings ${index + 1}`;
    const total = innings.totals || innings.total || innings.score || {};
    const totalText = typeof total === 'string' ? total : `${total.r ?? innings.r ?? '-'} / ${total.w ?? innings.w ?? '-'} (${total.o ?? innings.o ?? '-'})`;
    const rows = playerRows(innings);
    return `<section class="innings-card">
      <div class="innings-title"><b>${escapeHtml(title)}</b><strong>${escapeHtml(totalText)}</strong></div>
      ${rows ? `<div class="table-wrap"><table><thead><tr><th>Batter</th><th>Dismissal</th><th>R</th><th>B</th><th>4s</th><th>6s</th></tr></thead><tbody>${rows}</tbody></table></div>` : `<div style="padding:13px;color:var(--muted);font-size:11px">Detailed batting card will appear when provided by the live API.</div>`}
    </section>`;
  }

  function renderScorecard() {
    const match = selectedBaseMatch() || getSelected();
    if (!match) return `<div class="section-head"><div><span class="eyebrow">Scorecard</span><h1>Full scorecard</h1></div></div>${emptyState('No match selected', 'Select a fixture first.', '▤')}`;
    const innings = scorecardData();
    return `<div class="section-head"><div><span class="eyebrow">Scorecard</span><h1>${escapeHtml(teamInfo(match,0).name)} vs ${escapeHtml(teamInfo(match,1).name)}</h1><p>${escapeHtml(readableStatus(match))}</p></div></div>
      <div class="scorecard-grid">${innings.length ? innings.map(inningsHtml).join('') : `<section class="innings-card"><div class="innings-title"><b>Live innings summary</b><strong>${escapeHtml(readableStatus(match))}</strong></div><div style="padding:14px"><div class="score-line">${scoreChips(match)}</div><p class="safe-note">The detailed scorecard refreshes automatically when available from the provider.</p></div></section>`}</div>`;
  }

  function render() {
    updateNetworkDot();
    renderSelectedStrip();
    $$('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.tab === state.activeTab));

    if (state.loadingMatches && !state.matches.length) {
      screen.innerHTML = `<div class="section-head"><div><span class="eyebrow">Allrounder99</span><h1>Cricket feed</h1><p>Preparing live matches and fixtures</p></div></div><div class="card-list"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div>`;
      return;
    }

    const views = {
      home: renderHome,
      fixtures: renderFixtures,
      live: renderLive,
      commentary: renderCommentary,
      scorecard: renderScorecard
    };
    screen.innerHTML = (views[state.activeTab] || renderHome)();
    bindDynamicEvents();
    if (state.pageAnimation) {
      const animation = state.pageAnimation;
      state.pageAnimation = '';
      screen.classList.remove('page-enter-left', 'page-enter-right');
      void screen.offsetWidth;
      screen.classList.add(animation === 'left' ? 'page-enter-left' : 'page-enter-right');
    }
  }

  function bindDynamicEvents() {
    $$('[data-match-id]').forEach(card => card.addEventListener('click', () => selectMatch(card.dataset.matchId)));
    const soundToggle = $('#soundToggle');
    if (soundToggle) soundToggle.addEventListener('click', toggleSound);
    const reminderToggle = $('#reminderToggle');
    if (reminderToggle) reminderToggle.addEventListener('click', toggleReminder);
  }

  function selectMatch(id) {
    if (!id || id === state.selectedId) {
      state.activeTab = 'live';
      localStorage.setItem('a99_tab', state.activeTab);
      render();
      return;
    }
    state.selectedId = id;
    state.selectedDetails = null;
    state.scorecard = null;
    state.commentary = [];
    state.previousScoreFingerprint = '';
    localStorage.setItem('a99_selected_match', id);
    state.activeTab = 'live';
    localStorage.setItem('a99_tab', state.activeTab);
    render();
    updateSelectedDetails(true);
  }

  function toggleReminder() {
    const match = selectedBaseMatch() || getSelected();
    const date = match ? parseDate(match) : null;
    if (!match || !date) return;
    if (state.reminders.has(match.id)) {
      state.reminders.delete(match.id);
      try { window.A99Android.cancelReminder(match.id); } catch (_) {}
    } else {
      state.reminders.add(match.id);
      try { window.A99Android.scheduleReminder(match.id, `${teamInfo(match,0).name} vs ${teamInfo(match,1).name}`, date.getTime()); } catch (_) {}
    }
    localStorage.setItem('a99_reminders', JSON.stringify(Array.from(state.reminders)));
    render();
  }

  function toggleSound() {
    state.muted = !state.muted;
    localStorage.setItem('a99_muted', state.muted ? '1' : '0');
    if (state.muted) {
      try { window.A99Android.stopVoice(); } catch (_) {}
    }
    render();
  }

  function setTab(tab, animation = '') {
    if (!tab || tab === state.activeTab) return;
    state.pageAnimation = animation;
    state.activeTab = tab;
    localStorage.setItem('a99_tab', tab);
    render();
    window.scrollTo(0, 0);
    if (['live', 'commentary', 'scorecard'].includes(tab)) updateSelectedDetails(tab === 'scorecard');
  }

  function updateNetworkDot() {
    const online = navigator.onLine;
    networkDot.classList.toggle('offline', !online);
    if (networkText) networkText.textContent = online ? 'ONLINE' : 'OFFLINE';
  }

  function setupSwipe() {
    const order = ['home', 'fixtures', 'live', 'commentary', 'scorecard'];
    let startX = 0;
    let startY = 0;
    let lastX = 0;
    let startTime = 0;
    let tracking = false;
    let horizontal = false;

    const resetSurface = () => {
      screen.classList.remove('swipe-moving', 'swipe-release');
      screen.style.transform = '';
      screen.style.opacity = '';
    };

    screen.addEventListener('touchstart', event => {
      if (event.touches?.length !== 1 || !event.touches[0]) return;
      if (event.target.closest('input, textarea, select, .table-wrap')) return;
      startX = lastX = event.touches[0].clientX;
      startY = event.touches[0].clientY;
      startTime = performance.now();
      tracking = true;
      horizontal = false;
      screen.classList.remove('page-enter-left', 'page-enter-right', 'swipe-release');
    }, { passive: true });

    screen.addEventListener('touchmove', event => {
      if (!tracking || event.touches?.length !== 1) return;
      const touch = event.touches[0];
      const dx = touch.clientX - startX;
      const dy = touch.clientY - startY;
      lastX = touch.clientX;

      if (!horizontal) {
        if (Math.abs(dx) < 9 && Math.abs(dy) < 9) return;
        if (Math.abs(dy) >= Math.abs(dx) * 0.92) {
          tracking = false;
          resetSurface();
          return;
        }
        horizontal = true;
        screen.classList.add('swipe-moving');
      }

      event.preventDefault();
      const index = order.indexOf(state.activeTab);
      const atEdge = (index === 0 && dx > 0) || (index === order.length - 1 && dx < 0);
      const translated = dx * (atEdge ? 0.13 : 0.32);
      screen.style.transform = `translate3d(${translated}px, 0, 0)`;
      screen.style.opacity = String(Math.max(0.82, 1 - Math.abs(translated) / 900));
    }, { passive: false });

    const finish = event => {
      if (!tracking) return;
      tracking = false;
      const touch = event.changedTouches?.[0];
      const dx = (touch ? touch.clientX : lastX) - startX;
      const dy = (touch ? touch.clientY : startY) - startY;
      const elapsed = Math.max(1, performance.now() - startTime);
      const velocity = Math.abs(dx) / elapsed;
      const qualifies = horizontal
        && Math.abs(dx) > 34
        && Math.abs(dx) > Math.abs(dy) * 1.12
        && (Math.abs(dx) >= 58 || velocity >= 0.34);

      screen.classList.remove('swipe-moving');
      screen.classList.add('swipe-release');
      screen.style.transform = '';
      screen.style.opacity = '';
      window.setTimeout(() => screen.classList.remove('swipe-release'), 190);

      if (!qualifies) return;
      const index = order.indexOf(state.activeTab);
      const next = dx < 0 ? Math.min(order.length - 1, index + 1) : Math.max(0, index - 1);
      if (next !== index) setTab(order[next], dx < 0 ? 'left' : 'right');
    };

    screen.addEventListener('touchend', finish, { passive: true });
    screen.addEventListener('touchcancel', () => {
      tracking = false;
      horizontal = false;
      resetSurface();
    }, { passive: true });
  }

  function loadCache() {
    try {
      const cached = JSON.parse(localStorage.getItem('a99_matches_cache') || '[]');
      if (Array.isArray(cached) && cached.length) {
        state.matches = mergeMatches(cached);
        state.loadingMatches = false;
      }
    } catch (_) {}
    const selected = getSelected();
    if (selected) {
      try { state.commentary = JSON.parse(localStorage.getItem(`a99_commentary_${selected.id}`) || '[]'); } catch (_) {}
      try { state.scorecard = JSON.parse(localStorage.getItem(`a99_scorecard_${selected.id}`) || 'null'); } catch (_) {}
    }
  }

  function startTimers() {
    clearInterval(state.globalTimer);
    clearInterval(state.detailTimer);
    state.globalTimer = setInterval(refreshMatches, 300000);
    state.detailTimer = setInterval(() => {
      const selected = getSelected();
      if (selected && ['live', 'break'].includes(matchPhase(selected))) updateSelectedDetails(false);
    }, 60000);
  }

  window.A99App = {
    handleBack() {
      if (state.activeTab !== 'home') {
        setTab('home');
        return true;
      }
      return false;
    }
  };

  refreshButton?.addEventListener('click', () => {
    refreshMatches();
    if (['live', 'commentary', 'scorecard'].includes(state.activeTab)) updateSelectedDetails(state.activeTab === 'scorecard');
  });

  $$('.nav-item').forEach(button => button.addEventListener('click', () => {
    const order = ['home', 'fixtures', 'live', 'commentary', 'scorecard'];
    const current = order.indexOf(state.activeTab);
    const target = order.indexOf(button.dataset.tab);
    setTab(button.dataset.tab, target >= current ? 'left' : 'right');
  }));
  window.addEventListener('online', () => { updateNetworkDot(); refreshMatches(); });
  window.addEventListener('offline', updateNetworkDot);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      refreshMatches();
      if (['live', 'commentary', 'scorecard'].includes(state.activeTab)) updateSelectedDetails(state.activeTab === 'scorecard');
    }
  });

  loadCache();
  setupSwipe();
  render();
  refreshMatches();
  startTimers();
})();

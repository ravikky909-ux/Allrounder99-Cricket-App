plugins {
    id("com.android.application")
}

fun String.asBuildConfigString(): String =
    "\"" + replace("\\", "\\\\").replace("\"", "\\\"") + "\""

val cricketApiKey = providers.gradleProperty("CRICKET_API_KEY")
    .orElse(providers.environmentVariable("CRICKET_API_KEY"))
    .orElse("")

val signingStorePath = providers.environmentVariable("A99_KEYSTORE_PATH").orNull
val signingStorePassword = providers.environmentVariable("A99_KEYSTORE_PASSWORD").orNull
val signingKeyAlias = providers.environmentVariable("A99_KEY_ALIAS").orNull
val signingKeyPassword = providers.environmentVariable("A99_KEY_PASSWORD").orNull
val hasReleaseSigning = listOf(
    signingStorePath,
    signingStorePassword,
    signingKeyAlias,
    signingKeyPassword
).all { !it.isNullOrBlank() }

android {
    namespace = "com.allrounder99.cricket"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.allrounder99.cricket"
        minSdk = 23
        targetSdk = 35
        versionCode = 310
        versionName = "3.1.0"

        // Injected at build time from a Gradle property or environment variable.
        // It remains inside the compiled app, while staying out of public source control.
        buildConfigField("String", "CRICKET_API_KEY", cricketApiKey.get().asBuildConfigString())
        buildConfigField("String", "CRICKET_API_BASE", "https://api.cricapi.com/v1/".asBuildConfigString())
    }

    buildFeatures {
        buildConfig = true
    }

    if (hasReleaseSigning) {
        signingConfigs {
            create("release") {
                storeFile = file(signingStorePath!!)
                storePassword = signingStorePassword
                keyAlias = signingKeyAlias
                keyPassword = signingKeyPassword
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

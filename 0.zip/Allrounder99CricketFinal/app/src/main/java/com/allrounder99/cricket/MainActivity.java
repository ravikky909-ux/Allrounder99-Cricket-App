package com.allrounder99.cricket;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService apiExecutor = Executors.newFixedThreadPool(4);
    private WebView webView;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;

    @Override
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#06171B"));
        getWindow().setNavigationBarColor(Color.parseColor("#06171B"));
        createReminderChannel();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#06171B"));
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#06171B"));
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setVisibility(View.INVISIBLE);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(100);
        settings.setDefaultFontSize(16);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setUserAgentString(settings.getUserAgentString() + " Allrounder99Cricket/3.0");

        webView.addJavascriptInterface(new NativeBridge(), "A99Android");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            private boolean isBlocked(String url) {
                return url == null || !url.startsWith("file:///android_asset/");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return isBlocked(request == null ? null : request.getUrl().toString());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return isBlocked(url);
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        View splash = createSplashView();
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(new Locale("en", "IN"));
                textToSpeech.setSpeechRate(0.96f);
                textToSpeech.setPitch(1.02f);
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                        && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
        mainHandler.postDelayed(() -> {
            webView.setVisibility(View.VISIBLE);
            webView.setAlpha(0f);
            webView.animate().alpha(1f).setDuration(280).start();
            splash.animate()
                    .alpha(0f)
                    .setDuration(320)
                    .withEndAction(() -> root.removeView(splash))
                    .start();
        }, 1650);
    }

    private View createSplashView() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setGravity(Gravity.CENTER);
        container.setPadding(dp(32), dp(32), dp(32), dp(32));

        GradientDrawable background = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#041014"), Color.parseColor("#08343A"), Color.parseColor("#06171B")}
        );
        container.setBackground(background);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.allrounder99.cricket.R.drawable.a99_logo_full);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setAdjustViewBounds(true);
        GradientDrawable logoBg = new GradientDrawable();
        logoBg.setCornerRadius(dp(28));
        logoBg.setColor(Color.parseColor("#07343B"));
        logoBg.setStroke(dp(2), Color.parseColor("#22D8CE"));
        logo.setBackground(logoBg);
        logo.setClipToOutline(true);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(220), dp(220));
        logoParams.bottomMargin = dp(22);
        container.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("ALLROUNDER99 CRICKET");
        title.setTextColor(Color.WHITE);
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        container.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("LIVE • FIXTURES • COMMENTARY • SCORECARD");
        subtitle.setTextColor(Color.parseColor("#8FEAE5"));
        subtitle.setTextSize(12);
        subtitle.setLetterSpacing(0.12f);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        subParams.topMargin = dp(9);
        subParams.bottomMargin = dp(28);
        container.addView(subtitle, subParams);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        progress.getIndeterminateDrawable().setTint(Color.parseColor("#22D8CE"));
        container.addView(progress, new LinearLayout.LayoutParams(dp(36), dp(36)));
        return container;
    }

    private void createReminderChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                ReminderReceiver.CHANNEL_ID,
                "Match reminders",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Reminder before your selected cricket match starts");
        manager.createNotificationChannel(channel);
    }

    private void scheduleMatchReminder(String matchId, String title, long matchTimeMillis) {
        if (matchId == null || matchId.trim().isEmpty()) return;
        mainHandler.post(() -> {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9901);
            }
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) return;
            Intent intent = new Intent(this, ReminderReceiver.class);
            intent.putExtra("title", title == null ? "Selected cricket match" : title);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    this,
                    matchId.hashCode(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            long triggerAt = Math.max(System.currentTimeMillis() + 3000L, matchTimeMillis - 15L * 60L * 1000L);
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
        });
    }

    private void cancelMatchReminder(String matchId) {
        if (matchId == null || matchId.trim().isEmpty()) return;
        mainHandler.post(() -> {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) return;
            Intent intent = new Intent(this, ReminderReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    this,
                    matchId.hashCode(),
                    intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
            );
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent);
                pendingIntent.cancel();
            }
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void speakNow(String text) {
        if (!ttsReady || text == null || text.trim().isEmpty()) return;
        mainHandler.post(() -> textToSpeech.speak(
                text.trim(),
                TextToSpeech.QUEUE_FLUSH,
                null,
                "a99-ball-event"
        ));
    }

    private void sendToWeb(String requestId, String payload) {
        String script = "window.A99Native && window.A99Native.onApiResponse(" +
                JSONObject.quote(requestId) + "," + JSONObject.quote(payload) + ");";
        mainHandler.post(() -> webView.evaluateJavascript(script, null));
    }

    public final class NativeBridge {
        private final Set<String> allowedEndpoints = new HashSet<>(Arrays.asList(
                "currentMatches",
                "matches",
                "match_info",
                "match_scorecard",
                "match_bbb"
        ));

        @JavascriptInterface
        public void requestApi(String endpoint, String paramsJson, String requestId) {
            if (requestId == null || requestId.trim().isEmpty()) return;
            if (!allowedEndpoints.contains(endpoint)) {
                sendToWeb(requestId, "{\"status\":\"failure\",\"reason\":\"Endpoint not allowed\"}");
                return;
            }

            if (BuildConfig.CRICKET_API_KEY == null || BuildConfig.CRICKET_API_KEY.trim().isEmpty()) {
                sendToWeb(requestId, "{\"status\":\"failure\",\"reason\":\"API configuration missing\"}");
                return;
            }

            apiExecutor.execute(() -> {
                HttpURLConnection connection = null;
                try {
                    JSONObject params = (paramsJson == null || paramsJson.trim().isEmpty())
                            ? new JSONObject()
                            : new JSONObject(paramsJson);
                    params.put("apikey", BuildConfig.CRICKET_API_KEY);

                    StringBuilder query = new StringBuilder();
                    Iterator<String> keys = params.keys();
                    while (keys.hasNext()) {
                        String key = keys.next();
                        Object value = params.opt(key);
                        if (value == null || value == JSONObject.NULL) continue;
                        if (query.length() > 0) query.append('&');
                        query.append(URLEncoder.encode(key, StandardCharsets.UTF_8.name()));
                        query.append('=');
                        query.append(URLEncoder.encode(String.valueOf(value), StandardCharsets.UTF_8.name()));
                    }

                    URL url = new URL(BuildConfig.CRICKET_API_BASE + endpoint + "?" + query);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(9000);
                    connection.setReadTimeout(11000);
                    connection.setUseCaches(false);
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("User-Agent", "Allrounder99Cricket/3.0 Android");

                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 400
                            ? connection.getInputStream()
                            : connection.getErrorStream();
                    String body = readStream(stream);
                    if (body == null || body.trim().isEmpty()) {
                        body = "{\"status\":\"failure\",\"reason\":\"Empty API response\",\"httpCode\":" + code + "}";
                    }
                    sendToWeb(requestId, body);
                } catch (Exception error) {
                    String safeMessage = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
                    String body = "{\"status\":\"failure\",\"reason\":" + JSONObject.quote(safeMessage) + "}";
                    sendToWeb(requestId, body);
                } finally {
                    if (connection != null) connection.disconnect();
                }
            });
        }

        @JavascriptInterface
        public void speak(String text) {
            speakNow(text);
        }

        @JavascriptInterface
        public void stopVoice() {
            mainHandler.post(() -> {
                if (textToSpeech != null) textToSpeech.stop();
            });
        }

        @JavascriptInterface
        public void scheduleReminder(String matchId, String title, long matchTimeMillis) {
            scheduleMatchReminder(matchId, title, matchTimeMillis);
        }

        @JavascriptInterface
        public void cancelReminder(String matchId) {
            cancelMatchReminder(matchId);
        }

        @JavascriptInterface
        public String getVersion() {
            return BuildConfig.VERSION_NAME;
        }
    }

    private String readStream(InputStream inputStream) throws Exception {
        if (inputStream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
        }
        return result.toString();
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("window.A99App && window.A99App.handleBack ? window.A99App.handleBack() : false", value -> {
            if (!"true".equals(value)) super.onBackPressed();
        });
    }

    @Override
    protected void onPause() {
        if (textToSpeech != null) textToSpeech.stop();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        apiExecutor.shutdownNow();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (webView != null) {
            webView.removeJavascriptInterface("A99Android");
            webView.destroy();
        }
        super.onDestroy();
    }
}

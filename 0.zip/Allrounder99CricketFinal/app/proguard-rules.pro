-keepclassmembers class com.allrounder99.cricket.MainActivity$NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*

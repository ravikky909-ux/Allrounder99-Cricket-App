# Allrounder99 Cricket v3.0

Original teal cricket live-center UI for Android.

Features:
- Home, Fixtures, Live, Commentary and Scorecard remain synced to one selected match.
- CricAPI key is injected at build time through `CRICKET_API_KEY`; no API settings button is shown.
- Automatic live refresh, ball voice, rain/stumps/break status and safe win projection.
- Smooth horizontal swipe navigation with vertical-scroll protection.
- Allrounder99 logo in launcher icon, splash and header.

Build using `.github/workflows/build-apk.yml`. Add the GitHub Actions secret `CRICKET_API_KEY` first.

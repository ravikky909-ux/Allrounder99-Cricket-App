# Allrounder99 Cricket 2.2

Android cricket app with an original dark-teal interface inspired by the fast navigation style of leading cricket apps, without copying their UI.

## Included
- API key injected at build time and kept out of public source control; no API button in the app.
- Home, Fixtures, Live, Commentary and Scorecard synchronized to one selected match.
- Real running and upcoming fixtures feed.
- Automatic live refresh and ball-by-ball fetching.
- Mute/unmute control only inside the TV box.
- Voice events: Ball start, Six, Four, Single, Double, Triple, Out, Wide, No ball and Dot ball.
- Rain, stumps, innings break, lunch, tea, drinks, bad light and delay status handling.
- Informational win probability/projection only; no betting odds or rates.
- Cached last successful data for temporary network interruptions.
- GitHub workflow can produce an installable debug APK or a signed release APK.

## Required GitHub secret
Create this repository secret before running the workflow:

- `CRICKET_API_KEY` — the CricketData/CricAPI key.

The token is injected into `BuildConfig` during compilation. It will be inside the APK, as required, but not visible in the public repository or app UI. Any client-side APK token can still be extracted by a determined reverse engineer; a backend proxy is required for complete token secrecy.

## Optional signed release secrets
Add all four to build a signed release APK:

- `A99_KEYSTORE_BASE64`
- `A99_KEYSTORE_PASSWORD`
- `A99_KEY_ALIAS`
- `A99_KEY_PASSWORD`

Without these four secrets, the workflow builds an installable debug APK.

## Build
Upload the extracted project contents, or upload `0.zip` at the repository root with the standalone `build-0.yml` file saved as `.github/workflows/build-0.yml`.

Run **Actions → Build Allrounder99 Cricket APK → Run workflow**. Download the `Allrounder99-Cricket-APK` artifact.


## Smooth navigation (v2.2)
- Hardware-accelerated WebView rendering.
- Velocity-aware right/left swipe between Home, Fixtures, Live, Commentary and Scorecard.
- Finger-follow animation with edge resistance.
- Vertical scroll and scorecard-table protection prevent accidental tab changes.
- Selected match remains synced across every tab.
